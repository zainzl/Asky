# Akina-Siren
WordPress Theme

Siren-Akina 是基于 Akina 和 SirenMaseter 主题修改而来的，感谢[Fuzzz](http://www.akina.pw/) 和 [路易](https://www.i94.me/)写出这么棒的主题（[查看原始主题](http://www.akina.pw/themeakina) & （http://www.i94.me/26.html））。
应该属于两者综合版本吧，改成这样完全是因为觉得比较好玩

最新版本：1.0.0<br>
主要修改：<br>
- 2017-04-09<br>
融合akina的评论模板，支持添加表情<br>
作品列表替换为akina最新样式并修复移动端第一次加载不显示问题<br>
首页第一屏添加波浪动画（后台可关闭）<br>
全站添加蜂窝背景动效js(后台可关闭）<br>
页面顶部支持显示加载进度后者阅读进度（后台可关闭）<br>
页脚支持显示网站运行时间（后台可闭关并设置建站时间）<br>
公告支持添加闪现文字(后台设置）<br>
网站标题根据是否获取焦点判断（后台可闭关并自定议标题)<br>
左边Logo添加跳动特效<br>
右边头像自动获取<br>
友情链接自动获取对方favicon<br>
还有一些更小的我也记不住了……总之目前大概就这些
